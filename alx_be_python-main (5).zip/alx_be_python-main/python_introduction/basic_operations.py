number1 = 10
number2 = 5
sum_result = number1 + number2
difference_result = number1 - number2
product_result = number1 * number2

print("Addition of", number1, "and", number2, "is:", sum_result)
print("Subtraction of", number2, "from", number1, "is:", difference_result)
print("Multiplication of", number1, "and", number2, "is:", product_result)