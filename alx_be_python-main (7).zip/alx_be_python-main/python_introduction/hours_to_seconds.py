hours = 2
seconds = hours * 3600
print(f"{hours} hours is equal to {seconds} seconds.")