length = 10
width = 5
area = length * width
print("The area of the rectangle is:", area)