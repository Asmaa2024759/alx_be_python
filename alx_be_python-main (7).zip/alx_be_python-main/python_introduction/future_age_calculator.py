#Prompt the user to input their current age with the question: “How old are you? ”.
#Assume the user will input a valid integer value.
current_age = int(input("How old are you? "))

future_age = current_age + (2050 - 2023)
print("In 2050, you will be", future_age, "years old.")