class Book:
    """A class to represent a book in the library."""
    "attributes: title, author, private _is_checked_out"


    def __init__(self, title, author):
        self.title = title
        self.author = author
        self._is_checked_out = False

    def check_out(self):
        """Mark the book as checked out."""
        if not self._is_checked_out:
            self._is_checked_out = True
            return True
        return False

    def return_book(self):
        """Mark the book as returned."""
        if self._is_checked_out:
            self._is_checked_out = False
            return True
        return False

    
class Library:
    """A class to represent a library."""
    "attributes: name, books (list of Book objects)"

    def __init__(self):
        self._books = []

    def add_book(self, book):
        """Add a book to the library."""
        self._books.append(book)

    def remove_book(self, book):
        """Remove a book from the library."""
        if book in self._books:
            self._books.remove(book)
            return True
        return False

    def check_out_book(self, title):
        """Check out a book from the library."""
        for book in self._books:
            if book.title == title and not book._is_checked_out:
                book._is_checked_out = True
                return True
        return False

    def return_book(self, title):
        """Return a book to the library."""
        for book in self._books:
            if book.title == title and book._is_checked_out:
                book._is_checked_out = False
                return True
        return False

    def list_available_books(self):
        """List all available (not checked out) books."""
        available_books = [book for book in self._books if not book._is_checked_out]
        for book in available_books:
            print(f"{book.title} by {book.author}")
        if not available_books:
            print("No books available.")